# Lumora AI

AI-powered interior design web app that lets users upload room photos and generate stunning redesigns in multiple styles.

## Run & Operate

- **Frontend** (port 21203): workflow `artifacts/lumora-frontend: web` → `pnpm --filter @workspace/lumora-frontend run dev`
- **Backend** (port 8080): workflow `artifacts/api-server: API Server` → `dotnet run --project artifacts/api-server`
- Both services are proxied through the shared proxy at `/` (frontend) and `/api` (backend)

## Stack

- **Frontend**: React 19 + Vite + TypeScript, Tailwind CSS, Framer Motion, Recharts, Wouter
- **Backend**: ASP.NET 8 (C#), Entity Framework Core, SQLite
- **Auth**: JWT tokens (stored in localStorage), BCrypt password hashing
- **Monorepo**: pnpm workspaces

## Where things live

- `artifacts/lumora-frontend/src/` — React frontend
  - `context/AuthContext.tsx` — JWT auth state + API calls
  - `services/api.ts` — `apiGet/apiPost/apiPut/apiDelete` helpers
  - `pages/Dashboard/` — Settings, Overview, Projects, History, Favorites, Downloads
- `artifacts/api-server/` — ASP.NET 8 backend
  - `Program.cs` — all routes (auth + dashboard endpoints)
  - `Models/Entities.cs` — EF Core entities
  - `Data/AppDbContext.cs` — SQLite DbContext
  - `bin/Debug/net8.0/lumora.db` — SQLite database file

## Architecture decisions

- ASP.NET 8 backend (per user request) instead of the default Express.js scaffold
- SQLite for zero-configuration persistence; DB auto-created via EF Core `EnsureCreated()`
- JWT issued by backend; frontend stores in `localStorage` under key `lumora_token`
- New user registration auto-seeds sample projects, history, and favorites for demo purposes
- Dashboard pages show empty states (with loading skeletons) when API returns no data

## Product

- **Home**: Landing page with hero, gallery preview, testimonials, pricing, contact
- **Gallery**: Filterable community showcase of AI-generated room designs
- **Studio**: Upload a room photo → choose a style → generate AI redesign with before/after slider
- **Dashboard**: Personal workspace with overview stats, projects, history, favorites, downloads
- **Auth**: Sign up / log in with JWT; settings page allows name/username updates

## User preferences

- Backend must be ASP.NET 8 with SQLite (not Node.js/PostgreSQL)

## Gotchas

- Backend uses `--urls http://0.0.0.0:8080` (not the default port)
- SQLite DB lives in `artifacts/api-server/bin/Debug/net8.0/lumora.db` (AppContext.BaseDirectory)
- `SESSION_SECRET` env var is used as JWT signing key (with a fallback default for dev)
- `find <dir> -type f ! -perm -u+w -exec chmod u+w {} \;` needed after unzipping frontend files

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
